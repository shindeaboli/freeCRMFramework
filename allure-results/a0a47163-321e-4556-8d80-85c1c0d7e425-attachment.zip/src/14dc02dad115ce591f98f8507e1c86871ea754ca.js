import{test,expect} from '../fixture/GlobalFixture.js';


test.beforeEach("preCondition",async({page})=>{

await page.goto("/");

});


test("@e2e @Regresion verify user is on contact page", async({page,contactPage})=>{

    await contactPage.clickOnContactlink();

    await expect(page.url()).toContain("contacts");

});

test("@e2e @regression @sanity create new contact" , async({page, contactPage})=>{

    await contactPage.clickOnContactlink();
    await contactPage.clickOnCreateButton();
    await contactPage.enterFirstname("Aboli");
    await contactPage.enterLastname("yadav");
    await contactPage.enterEmail("aboli123@gmail.com");
    await contactPage.clickOnSaveButton();

});