import {test, expect} from '@playwright/test';
import LoginPage from '../pages/LoginPage';
import ContactPage from '../pages/ContactPage.js';



    const customTest = test.extend({

    loginPage : async ({page}, use )=>{
       await use (new LoginPage(page)); 
    },

    
    contactPage : async({page}, use) =>{

        await use(new ContactPage(page));
    }


});

module.exports={test:  customTest, expect}

